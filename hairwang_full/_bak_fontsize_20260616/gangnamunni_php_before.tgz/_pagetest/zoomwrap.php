<?php
/**
 * [테스트 전용] zoom 비교 래퍼
 * 실제 페이지(같은 디렉토리)를 가져와 body 에 zoom 을 입혀 보여줌.
 * 운영 페이지/설정은 전혀 안 건드림. zoom_compare.html 이 iframe 으로 띄움.
 * 사용: zoomwrap.php?page=hospitals.php&z=0.85
 */
$page = isset($_GET['page']) ? basename($_GET['page']) : 'hospitals.php';
$z    = isset($_GET['z']) ? floatval($_GET['z']) : 1.0;
if ($z <= 0 || $z > 2) $z = 1.0;

// 허용 페이지만 (보안)
$allow = ['index.php','hospitals.php','reviews.php','events.php','community.php',
          'columns.php','price_compare.php','treatments.php','mypage.php',
          'detail.php','my_bookings.php','hospital_ranking.php'];
if (!in_array($page, $allow)) $page = 'hospitals.php';

// 실제 페이지를 서버 내부에서 호출해 HTML 가져오기 (모바일 UA 로 — 반응형 그대로)
$base = 'https://hms.seoulbeauty.app/hairwang/gangnamunni/';
$url  = $base . $page;
$ctx = stream_context_create([
  'http' => ['header' => "User-Agent: Mozilla/5.0 (Linux; Android 10; SM-G973F)\r\n", 'timeout' => 15],
  'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
]);
$html = @file_get_contents($url, false, $ctx);
if ($html === false) { echo '페이지 로드 실패: '.htmlspecialchars($page); exit; }

// 상대경로가 깨지지 않게 <base> 주입 + zoom 스크립트 주입
$inject_head = '<base href="'.$base.'">';
$html = preg_replace('/<head([^>]*)>/i', '<head$1>'.$inject_head, $html, 1);

$inject_body = '<script>window.addEventListener("load",function(){document.body.style.zoom="'.$z.'";});</script>';
$html = preg_replace('/<\/body>/i', $inject_body.'</body>', $html, 1);

header('Content-Type: text/html; charset=utf-8');
echo $html;
