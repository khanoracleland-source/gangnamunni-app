<?php
/**
 * AI 자동화 설정 페이지 (슈퍼 어드민 전용)
 * - AI 기능별 ON/OFF 토글
 * - 임계값 설정
 * - 자동화 규칙 관리
 * - API 키 관리 (Phase D)
 */
session_start();

// DB 연결
require_once __DIR__ . '/../dbconfig.php';
$connect = mysqli_connect(G5_MYSQL_HOST, G5_MYSQL_USER, G5_MYSQL_PASSWORD, G5_MYSQL_DB, G5_MYSQL_PORT);
if (!$connect) die("MySQL 접속 실패: " . mysqli_connect_error());
mysqli_set_charset($connect, 'utf8mb4');
require_once __DIR__ . '/theme_helper.php';
if (!function_exists('term')) { require_once __DIR__ . '/includes/industry_terms.php'; }
loadThemeSettings($connect);


// 인증
require_once __DIR__ . '/includes/admin_auth.php';
require_admin_login();
require_permission('ai_settings');

// AI 설정 키 정의
$ai_setting_keys = [
    // 후기 AI
    ['key' => 'ai_check_enabled', 'label' => '후기 AI 검수', 'desc' => '후기 등록 시 AI가 자동으로 내용을 분석하여 스팸/비속어/품질 체크', 'group' => 'review', 'type' => 'toggle'],
    ['key' => 'ai_min_score', 'label' => 'AI 최소 점수', 'desc' => '이 점수 미만이면 자동 보류 (0~100)', 'group' => 'review', 'type' => 'number', 'min' => 0, 'max' => 100],
    ['key' => 'auto_approve', 'label' => '후기 자동 승인', 'desc' => 'AI 검수 통과 시 자동으로 게시 (OFF: 수동 승인 필요)', 'group' => 'review', 'type' => 'toggle'],

    // 광고 AI
    ['key' => 'ai_ad_check', 'label' => '광고 AI 검수', 'desc' => '광고 신청 시 과대광고/허위 키워드 자동 탐지', 'group' => 'ad', 'type' => 'toggle'],
    ['key' => 'ai_ad_min_score', 'label' => '광고 AI 최소 점수', 'desc' => '이 점수 미만 광고는 자동 보류', 'group' => 'ad', 'type' => 'number', 'min' => 0, 'max' => 100],
    ['key' => 'ai_ad_auto_approve', 'label' => '광고 자동 승인', 'desc' => 'AI 통과 광고 자동 활성화', 'group' => 'ad', 'type' => 'toggle'],

    // 병원 AI
    ['key' => 'ai_hospital_check', 'label' => '병원 등록 AI 검증', 'desc' => '병원 등록 시 필수정보 누락/중복 자동 체크', 'group' => 'hospital', 'type' => 'toggle'],
    ['key' => 'ai_hospital_auto_approve', 'label' => '병원 자동 승인', 'desc' => 'AI 검증 통과 병원 자동 활성화', 'group' => 'hospital', 'type' => 'toggle'],

    // 스팸/이상탐지
    ['key' => 'ai_spam_detect', 'label' => '스팸 자동 감지', 'desc' => '중복 IP/내용 패턴으로 스팸 자동 차단', 'group' => 'system', 'type' => 'toggle'],
    ['key' => 'ai_anomaly_alert', 'label' => '이상 징후 알림', 'desc' => '비정상 트래픽/대량 등록 감지 시 관리자 알림', 'group' => 'system', 'type' => 'toggle'],
    ['key' => 'ai_content_suggest', 'label' => '내용 개선 제안', 'desc' => '후기/광고 작성 시 AI가 개선점 실시간 제안', 'group' => 'system', 'type' => 'toggle'],
];

// AJAX 처리
if (isset($_POST['ajax_action'])) {
    header('Content-Type: application/json; charset=utf-8');

    if ($_POST['ajax_action'] === 'save_settings') {
        $settings = json_decode($_POST['settings'] ?? '{}', true);
        if (!$settings) {
            echo json_encode(['success' => false, 'error' => '설정 데이터 오류']);
            exit;
        }

        $saved = 0;
        foreach ($settings as $key => $value) {
            // 허용된 키만 저장
            $allowed = array_column($ai_setting_keys, 'key');
            if (!in_array($key, $allowed)) continue;

            $value = strval($value);
            $result = mysqli_query($connect,
                "SELECT id FROM editor_settings WHERE setting_key = '" . mysqli_real_escape_string($connect, $key) . "'");
            if (mysqli_num_rows($result) > 0) {
                mysqli_query($connect,
                    "UPDATE editor_settings SET setting_value = '" . mysqli_real_escape_string($connect, $value) . "' WHERE setting_key = '" . mysqli_real_escape_string($connect, $key) . "'");
            } else {
                mysqli_query($connect,
                    "INSERT INTO editor_settings (setting_key, setting_value) VALUES ('" . mysqli_real_escape_string($connect, $key) . "', '" . mysqli_real_escape_string($connect, $value) . "')");
            }
            $saved++;
        }

        echo json_encode(['success' => true, 'saved' => $saved]);
        exit;
    }

    if ($_POST['ajax_action'] === 'get_ai_stats') {
        $stats = [];

        // 후기 AI 통계
        $r = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as c FROM review_ai_logs"));
        $stats['review_checks'] = (int)($r['c'] ?? 0);

        $r = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as c FROM review_ai_logs WHERE passed = 1"));
        $stats['review_passed'] = (int)($r['c'] ?? 0);

        $r = mysqli_fetch_assoc(mysqli_query($connect, "SELECT AVG(score) as avg FROM review_ai_logs"));
        $stats['review_avg_score'] = round((float)($r['avg'] ?? 0), 1);

        // 승인 대기 현황
        $r = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as c FROM hospital_reviews WHERE review_status = 'pending'"));
        $stats['pending_reviews'] = (int)($r['c'] ?? 0);

        $r = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as c FROM gangnamunni_ads WHERE status = 'pending'"));
        $stats['pending_ads'] = (int)($r['c'] ?? 0);

        $r = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as c FROM gangnamunni_hospitals WHERE status = 'pending'"));
        $stats['pending_hospitals'] = (int)($r['c'] ?? 0);

        echo json_encode(['success' => true, 'stats' => $stats]);
        exit;
    }

    echo json_encode(['success' => false, 'error' => 'Unknown action']);
    exit;
}

// 현재 설정값 로드
$current_settings = [];
$result = mysqli_query($connect, "SELECT setting_key, setting_value FROM editor_settings");
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $current_settings[$row['setting_key']] = $row['setting_value'];
    }
}

// 기본값 설정
$defaults = [
    'ai_check_enabled' => '1', 'ai_min_score' => '70', 'auto_approve' => '0',
    'ai_ad_check' => '0', 'ai_ad_min_score' => '60', 'ai_ad_auto_approve' => '0',
    'ai_hospital_check' => '0', 'ai_hospital_auto_approve' => '0',
    'ai_spam_detect' => '1', 'ai_anomaly_alert' => '0', 'ai_content_suggest' => '0',
];
foreach ($defaults as $k => $v) {
    if (!isset($current_settings[$k])) {
        $current_settings[$k] = $v;
    }
}

$groups = [
    'review' => ['label' => '후기 AI 검수', 'icon' => 'bi-chat-dots', 'color' => '#667eea'],
    'ad' => ['label' => '광고 AI 검수', 'icon' => 'bi-megaphone', 'color' => '#4facfe'],
    'hospital' => ['label' => '병원 등록 AI', 'icon' => 'bi-hospital', 'color' => '#43e97b'],
    'system' => ['label' => '시스템 AI', 'icon' => 'bi-cpu', 'color' => '#fa709a'],
];

// HTML 페이지 렌더링
$admin_page_title = 'AI 자동화 설정';
$admin_current = 'ai_settings';
require_once __DIR__ . '/includes/admin_header.php';
?>

<style>
.ai-group-card { border: none; border-radius: 12px; overflow: hidden; }
.ai-group-header { padding: 16px 20px; color: #fff; font-weight: 600; }
.ai-setting-row { display: flex; align-items: center; justify-content: space-between; padding: 14px 20px; border-bottom: 1px solid #f0f0f0; }
.ai-setting-row:last-child { border-bottom: none; }
.ai-setting-info { flex: 1; padding-right: 16px; }
.ai-setting-label { font-weight: 600; font-size: 14px; }
.ai-setting-desc { font-size: 12px; color: #888; margin-top: 2px; }
.ai-toggle { position: relative; width: 52px; height: 28px; flex-shrink: 0; }
.ai-toggle input { display: none; }
.ai-toggle-slider { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: #ddd; border-radius: 28px; cursor: pointer; transition: 0.3s; }
.ai-toggle-slider::before { content: ''; position: absolute; width: 22px; height: 22px; left: 3px; top: 3px; background: var(--bs-body-bg); border-radius: 50%; transition: 0.3s; box-shadow: 0 1px 3px rgba(0,0,0,0.2); }
.ai-toggle input:checked + .ai-toggle-slider { background: #667eea; }
.ai-toggle input:checked + .ai-toggle-slider::before { transform: translateX(24px); }
.ai-number-input { width: 80px; padding: 4px 8px; border: 1px solid var(--bs-border-color); border-radius: 8px; text-align: center; font-weight: 600; }
.stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 12px; margin-bottom: 20px; }
.stat-box { padding: 16px; border-radius: 12px; background: var(--bs-tertiary-bg, #f8f9fa); text-align: center; }
.stat-box .value { font-size: 28px; font-weight: 700; }
.stat-box .label { font-size: 12px; color: #888; margin-top: 4px; }
.save-bar { position: sticky; bottom: 0; padding: 12px 20px; background: var(--bs-body-bg); border-top: 1px solid var(--bs-border-color); z-index: 50; }
.ai-status-badge { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; }
.ai-status-on { background: #d4edda; color: #155724; }
.ai-status-off { background: #f8d7da; color: #721c24; }

/* API 키 관리 - 그룹 아코디언 */
.key-provider-group { border: none; border-radius: 12px; overflow: hidden; margin-bottom: 12px; }
.key-provider-header { padding: 14px 20px; color: #fff; font-weight: 600; cursor: pointer; display: flex; align-items: center; justify-content: space-between; transition: opacity 0.2s; border: none; width: 100%; }
.key-provider-header:hover { opacity: 0.9; }
.key-provider-header .provider-info { display: flex; align-items: center; gap: 10px; }
.key-provider-header .provider-count { background: rgba(255,255,255,0.25); padding: 2px 10px; border-radius: 12px; font-size: 12px; }
.key-provider-header .collapse-icon { transition: transform 0.3s; font-size: 18px; }
.key-provider-header.collapsed .collapse-icon { transform: rotate(-90deg); }
.key-provider-body { max-height: 2000px; overflow: hidden; transition: max-height 0.4s ease; }
.key-provider-body.collapsed { max-height: 0; }
.key-card { display: flex; align-items: center; padding: 14px 20px; border-bottom: 1px solid #f0f0f0; gap: 16px; flex-wrap: wrap; }
.key-card:last-child { border-bottom: none; }
.key-card-main { flex: 1; min-width: 200px; }
.key-card-model { font-weight: 600; font-size: 14px; }
.key-card-masked { font-family: monospace; font-size: 12px; color: #888; margin-top: 2px; }
.key-card-meta { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
.key-meta-item { display: flex; flex-direction: column; align-items: center; min-width: 60px; }
.key-meta-item .meta-value { font-weight: 700; font-size: 14px; }
.key-meta-item .meta-label { font-size: 10px; color: #999; text-transform: uppercase; }
.key-card-date { font-size: 12px; color: #aaa; white-space: nowrap; }
.key-card-actions { display: flex; gap: 6px; }
.provider-bg-anthropic { background: linear-gradient(135deg, #d97706, #b45309); }
.provider-bg-openai { background: linear-gradient(135deg, #10a37f, #0d8c6d); }
.provider-bg-google { background: linear-gradient(135deg, #4285f4, #3367d6); }
.provider-bg-default { background: linear-gradient(135deg, #6b7280, #4b5563); }
/* 다크모드 오버라이드 */
[data-bs-theme="dark"] .ai-setting-row { border-bottom-color: var(--bs-border-color); }
[data-bs-theme="dark"] .key-card { border-bottom-color: var(--bs-border-color); }
[data-bs-theme="dark"] .ai-toggle-slider { background: #495057; }
[data-bs-theme="dark"] .ai-status-on { background: #1a3a2a; color: #75b798; }
[data-bs-theme="dark"] .ai-status-off { background: #3a1a1a; color: #ea868f; }
[data-bs-theme="dark"] .ai-number-input { background: #2b3035; border-color: var(--bs-border-color); color: var(--bs-body-color); }
[data-bs-theme="dark"] .ai-group-card { background: var(--bs-body-bg); }
</style>

<!-- AI 키 발급 안내 배너 -->
<div class="card mb-4" style="border: 2px solid #3B82F6; border-radius: 12px; overflow: hidden;">
    <div class="card-body" style="background: linear-gradient(135deg, rgba(59,130,246,0.08), rgba(139,92,246,0.08));">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
            <div>
                <h6 class="fw-bold mb-1"><i class="bi bi-lightbulb-fill text-warning me-2"></i>AI 기능을 사용하려면 API 키가 필요합니다</h6>
                <p class="small mb-0" style="color: #666;">
                    Zhipu GLM <strong>(무료)</strong>, OpenAI ($5~), Anthropic ($5~), DeepSeek ($5~) 등 6개 프로바이더 지원.
                    <strong>GLM-4.7-Flash는 완전 무료</strong>로 신용카드 없이 가입만 하면 바로 사용 가능합니다.
                </p>
            </div>
            <a href="manual/ai_key_guide.html" target="_blank" class="btn btn-primary" style="border-radius: 10px; white-space: nowrap; background: linear-gradient(135deg, #3B82F6, #8B5CF6); border: none; font-weight: 600;">
                <i class="bi bi-book me-1"></i> API 키 발급 가이드
            </a>
        </div>
    </div>
</div>

<!-- 통계 대시보드 -->
<div class="card mb-4">
    <div class="card-body">
        <h6 class="fw-bold mb-3"><i class="bi bi-graph-up-arrow"></i> AI 운영 현황</h6>
        <div class="stats-grid" id="aiStats">
            <div class="stat-box">
                <div class="value" id="statReviewChecks">-</div>
                <div class="label">후기 AI 검수</div>
            </div>
            <div class="stat-box">
                <div class="value" id="statReviewPassed">-</div>
                <div class="label">검수 통과</div>
            </div>
            <div class="stat-box">
                <div class="value" id="statAvgScore">-</div>
                <div class="label">평균 AI 점수</div>
            </div>
            <div class="stat-box">
                <div class="value text-warning" id="statPendingReviews">-</div>
                <div class="label">후기 승인 대기</div>
            </div>
            <div class="stat-box">
                <div class="value text-info" id="statPendingAds">-</div>
                <div class="label">광고 승인 대기</div>
            </div>
            <div class="stat-box">
                <div class="value text-success" id="statPendingHospitals">-</div>
                <div class="label">병원 승인 대기</div>
            </div>
        </div>
    </div>
</div>

<!-- AI 설정 그룹 -->
<?php foreach ($groups as $group_key => $group): ?>
<div class="card ai-group-card mb-3">
    <div class="ai-group-header" style="background: <?= $group['color'] ?>;">
        <i class="bi <?= $group['icon'] ?> me-2"></i> <?= $group['label'] ?>
    </div>
    <div class="card-body p-0">
        <?php foreach ($ai_setting_keys as $setting):
            if ($setting['group'] !== $group_key) continue;
            $val = $current_settings[$setting['key']] ?? '0';
        ?>
        <div class="ai-setting-row">
            <div class="ai-setting-info">
                <div class="ai-setting-label">
                    <?= htmlspecialchars($setting['label']) ?>
                    <span class="ai-status-badge <?= $val && $val !== '0' ? 'ai-status-on' : 'ai-status-off' ?>" id="badge_<?= $setting['key'] ?>">
                        <?= $val && $val !== '0' ? 'ON' : 'OFF' ?>
                    </span>
                </div>
                <div class="ai-setting-desc"><?= htmlspecialchars($setting['desc']) ?></div>
            </div>
            <?php if ($setting['type'] === 'toggle'): ?>
            <label class="ai-toggle">
                <input type="checkbox" data-key="<?= $setting['key'] ?>" <?= $val === '1' ? 'checked' : '' ?> onchange="markDirty()">
                <span class="ai-toggle-slider"></span>
            </label>
            <?php elseif ($setting['type'] === 'number'): ?>
            <input type="number" class="ai-number-input" data-key="<?= $setting['key'] ?>"
                   value="<?= htmlspecialchars($val) ?>"
                   min="<?= $setting['min'] ?? 0 ?>" max="<?= $setting['max'] ?? 100 ?>"
                   onchange="markDirty()">
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endforeach; ?>

<!-- HMS 연동 정보 -->
<div class="card mb-3">
    <div class="card-body">
        <h6 class="fw-bold mb-3"><i class="bi bi-link-45deg"></i> HMS 연동</h6>
        <div class="table-responsive">
            <table class="table table-sm mb-0">
                <thead><tr><th>기능</th><th>HMS URL</th><th>상태</th></tr></thead>
                <tbody>
                    <tr>
                        <td>병원 관리</td>
                        <td><a href="https://hms.seoulbeauty.app/super-admin/hospitals" target="_blank">/super-admin/hospitals</a></td>
                        <td><span class="badge bg-success">연동됨</span></td>
                    </tr>
                    <tr>
                        <td>의사 관리</td>
                        <td><a href="https://hms.seoulbeauty.app/super-admin/doctors" target="_blank">/super-admin/doctors</a></td>
                        <td><span class="badge bg-success">연동됨</span></td>
                    </tr>
                    <tr>
                        <td>후기 관리</td>
                        <td><a href="https://hms.seoulbeauty.app/hospital-reviews" target="_blank">/hospital-reviews</a></td>
                        <td><span class="badge bg-success">연동됨</span></td>
                    </tr>
                    <tr>
                        <td>시술 분류</td>
                        <td><a href="https://hms.seoulbeauty.app/super-admin/hospital-type" target="_blank">/super-admin/hospital-type</a></td>
                        <td><span class="badge bg-success">연동됨</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ======================================================== -->
<!-- API 키 관리 섹션 (프로바이더별 그룹, 확장/축소) -->
<!-- ======================================================== -->
<div id="ai-key-management" class="mt-4">
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="bi bi-key"></i> API 키 관리</h5>
            <div>
                <button class="btn btn-outline-light btn-sm me-1" onclick="toggleAllGroups()" title="모두 펼치기/접기">
                    <i class="bi bi-arrows-expand" id="toggleAllIcon"></i>
                </button>
                <button class="btn btn-success btn-sm" onclick="showAddKeyModal()">
                    <i class="bi bi-plus-lg"></i> 키 등록
                </button>
            </div>
        </div>
        <div class="card-body p-3" id="keyGroupContainer">
            <div class="text-center py-4 text-muted">로딩 중...</div>
        </div>
    </div>

    <!-- 사용량 통계 -->
    <div class="card border-0 shadow-sm mt-3">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-graph-up"></i> AI 사용량 통계</h5>
        </div>
        <div class="card-body">
            <div class="row" id="aiUsageStats">
                <div class="col-12 text-center text-muted py-3">로딩 중...</div>
            </div>
        </div>
    </div>
</div>

<!-- API 키 등록 모달 -->
<div class="modal fade" id="addKeyModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">AI API 키 등록</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">프로바이더</label>
                    <select id="keyProvider" class="form-select">
                        <option value="anthropic">Anthropic (Claude)</option>
                        <option value="openai">OpenAI (GPT)</option>
                        <option value="google">Google (Gemini)</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">API 키</label>
                    <div class="input-group">
                        <input type="password" id="keyValue" class="form-control" placeholder="sk-...">
                        <button class="btn btn-outline-secondary" type="button" onclick="toggleKeyVisibility()">
                            <i class="bi bi-eye" id="keyEyeIcon"></i>
                        </button>
                    </div>
                    <small class="text-muted">AES-256-CBC 암호화 저장됩니다</small>
                </div>
                <div class="mb-3">
                    <label class="form-label">모델명 (선택)</label>
                    <input type="text" id="keyModel" class="form-control" placeholder="기본 모델 사용 시 비워두세요">
                    <small class="text-muted">
                        Anthropic: claude-haiku-4-5-20251001 | OpenAI: gpt-4o-mini | Google: gemini-2.0-flash
                    </small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">취소</button>
                <button type="button" class="btn btn-primary" onclick="registerKey()">
                    <i class="bi bi-shield-lock"></i> 암호화 저장
                </button>
            </div>
        </div>
    </div>
</div>

<!-- 저장 바 -->
<div class="save-bar text-end" id="saveBar" style="display:none;">
    <span class="text-warning me-3" id="saveStatus"><i class="bi bi-exclamation-circle"></i> 변경사항이 있습니다</span>
    <button class="btn btn-primary" onclick="saveSettings()"><i class="bi bi-check-lg"></i> 설정 저장</button>
</div>

<script>
let isDirty = false;

function markDirty() {
    isDirty = true;
    document.getElementById('saveBar').style.display = '';
}

function saveSettings() {
    const settings = {};
    document.querySelectorAll('[data-key]').forEach(el => {
        if (el.type === 'checkbox') {
            settings[el.dataset.key] = el.checked ? '1' : '0';
        } else {
            settings[el.dataset.key] = el.value;
        }
    });

    const fd = new FormData();
    fd.append('ajax_action', 'save_settings');
    fd.append('settings', JSON.stringify(settings));

    fetch(location.href, { method: 'POST', body: fd })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                isDirty = false;
                document.getElementById('saveBar').style.display = 'none';
                // 배지 업데이트
                document.querySelectorAll('[data-key]').forEach(el => {
                    const badge = document.getElementById('badge_' + el.dataset.key);
                    if (!badge) return;
                    let val;
                    if (el.type === 'checkbox') val = el.checked;
                    else val = el.value && el.value !== '0';
                    badge.className = 'ai-status-badge ' + (val ? 'ai-status-on' : 'ai-status-off');
                    badge.textContent = val ? 'ON' : 'OFF';
                });
                alert('설정이 저장되었습니다.');
            } else {
                alert('저장 실패: ' + (d.error || ''));
            }
        })
        .catch(e => alert('오류: ' + e.message));
}

function loadStats() {
    const fd = new FormData();
    fd.append('ajax_action', 'get_ai_stats');
    fetch(location.href, { method: 'POST', body: fd })
        .then(r => r.json())
        .then(d => {
            if (!d.success) return;
            const s = d.stats;
            document.getElementById('statReviewChecks').textContent = s.review_checks;
            document.getElementById('statReviewPassed').textContent = s.review_passed;
            document.getElementById('statAvgScore').textContent = s.review_avg_score;
            document.getElementById('statPendingReviews').textContent = s.pending_reviews;
            document.getElementById('statPendingAds').textContent = s.pending_ads;
            document.getElementById('statPendingHospitals').textContent = s.pending_hospitals;
        });
}

loadStats();

window.addEventListener('beforeunload', function(e) {
    if (isDirty) { e.preventDefault(); e.returnValue = ''; }
});
</script>

<?php include __DIR__ . '/includes/admin_footer.php'; ?>
