<?php
/**
 * 모바일 카테고리 반응형 스케일 설정
 * 기기별(PC/Android/iOS) × 요소별 + 대상선택 일률적용 + 저장/원복 + 미리보기(복사본 iframe)
 * @created 2026-06-16
 * 동작: 입력 → 미리보기(index_preview.php 복사본에 즉시반영, DB저장X) → 저장 버튼 → DB반영(운영 적용)
 */
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

$admin_page_title = '모바일 스케일 설정';
$admin_current = 'mobile_scale';

require_once __DIR__ . '/dbconfig.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/theme_helper.php';
require_once __DIR__ . '/includes/admin_auth.php';

$connect = mysqli_connect(G5_MYSQL_HOST, G5_MYSQL_USER, G5_MYSQL_PASSWORD, G5_MYSQL_DB, G5_MYSQL_PORT);
if (!$connect) die("MySQL 연결 실패");
mysqli_set_charset($connect, 'utf8mb4');
loadThemeSettings($connect);

require_admin_login();

$cfg = [];
$res = mysqli_query($connect, "SELECT setting_key, setting_value FROM gangnamunni_settings WHERE setting_group='mobile_scale'");
while ($row = mysqli_fetch_assoc($res)) { $cfg[$row['setting_key']] = $row['setting_value']; }
function cs($k, $d='') { global $cfg; return $cfg[$k] ?? $d; }

$devices = ['pc'=>'💻 PC', 'android'=>'🤖 Android', 'ios'=>'🍎 iOS'];
$fields = [
  'enabled' => ['적용 여부', '1', '이 기기에서 반응형 스케일을 켜고 끕니다. OFF 시 원래 크기(고정)로 표시.'],
  'factor'  => ['Factor (배율)', '0', '전체 축소 배율. <b>0=자동</b>(화면폭÷390, 좁을수록 작게). 0보다 큰 값 입력 시 그 값으로 고정(0.7=70%). 보통 0 권장.'],
  'adjust'  => ['전체 보정', '1.0', 'Factor에 곱하는 미세 보정. <b>모든 요소(글자·셀·칩) 동시</b>. 작을수록 전체 작아짐. 모바일 기본 0.7=서브 3개(피그마 일치).'],
  'font'    => ['글자 보정', '1.0', '<b>글자 크기만</b> 추가 조정. 0.9=10% 작게.'],
  'pad'     => ['셀높이 보정', '1.0', '<b>행 높이(여백)만</b> 조정. 0.8=행 촘촘하게.'],
  'chip'    => ['칩 보정', '1.0', '<b>서브 칩(써마지FLX 등)만</b> 조정. 0.9=칩 작게 해 더 많이 표시.'],
];
$defaults = [
  'pc'      => ['enabled'=>'1','factor'=>'0','adjust'=>'1.0','font'=>'1.0','pad'=>'1.0','chip'=>'1.0'],
  'android' => ['enabled'=>'1','factor'=>'0','adjust'=>'0.7','font'=>'1.0','pad'=>'1.0','chip'=>'1.0'],
  'ios'     => ['enabled'=>'1','factor'=>'0','adjust'=>'0.7','font'=>'1.0','pad'=>'1.0','chip'=>'1.0'],
];

require_once __DIR__ . '/includes/admin_header.php';
?>
<style>
.ms-wrap{display:flex;gap:16px;align-items:flex-start}
.ms-left{flex:1;min-width:0}
.ms-preview{flex:none;width:400px;position:sticky;top:10px}
.ms-preview .phone{border:8px solid #222;border-radius:24px;overflow:hidden;background:#000;box-shadow:0 8px 30px rgba(0,0,0,.3)}
.ms-preview iframe{width:100%;height:620px;border:0;background:#fff;display:block}
.ms-dirty{display:none}
body.ms-has-dirty .ms-dirty{display:inline}
@media (max-width:1100px){ .ms-wrap{flex-direction:column} .ms-preview{width:100%;position:static} }
</style>
<div class="container-fluid py-3" style="max-width:1400px">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-phone"></i> 모바일 카테고리 반응형 스케일</h4>
    <div class="d-flex gap-2">
      <select id="prevDevice" class="form-select form-select-sm" style="width:auto" onchange="refreshPreview()">
        <option value="android">🤖 Android 미리보기</option>
        <option value="ios">🍎 iOS 미리보기</option>
        <option value="pc">💻 PC 미리보기</option>
      </select>
      <button class="btn btn-sm btn-primary" onclick="updatePreview()"><i class="bi bi-eye"></i> 미리보기 적용</button>
    </div>
  </div>

  <div id="saveAlert" class="alert alert-success d-none" style="position:sticky;top:8px;z-index:50"><i class="bi bi-check-circle"></i> <span id="saveMsg">저장됨</span></div>

  <div class="alert alert-warning" style="font-size:13.5px;line-height:1.7">
    ⚠️ <b>입력해도 바로 적용되지 않습니다.</b> 값 변경 → <b>[미리보기 적용]</b> 으로 오른쪽 화면 확인 → 만족하면 <b>[저장]</b> 버튼으로 운영 반영.
    <span class="ms-dirty text-danger fw-bold">　● 저장 안 된 변경사항이 있습니다.</span>
  </div>

  <!-- 동작 방식 설명 -->
  <details class="card mb-3" style="border-left:4px solid #0d6efd">
    <summary class="card-header fw-bold" style="cursor:pointer;list-style:revert"><i class="bi bi-info-circle"></i> 이 설정은 어떻게 동작하나요? (클릭하여 펼치기)</summary>
    <div class="card-body" style="font-size:13.5px;line-height:1.8">
      <p class="mb-2"><b>📍 적용 범위:</b> <b>메인 페이지(index.php)의 시술 카테고리 표</b>에만 적용됩니다. 다른 페이지(병원목록·후기 등)에는 영향 없습니다.</p>
      <p class="mb-2"><b>🎯 왜 필요한가:</b> 카테고리 표의 글자·셀 크기가 고정(px)이라 폰 화면이 좁으면 칸이 2개만 보였습니다. 화면 폭에 맞춰 <b>비례 축소</b>하면 피그마 디자인처럼 서브 3개가 보입니다.</p>
      <p class="mb-2"><b>⚙️ 동작 흐름:</b></p>
      <ol class="mb-2" style="padding-left:20px">
        <li>관리자가 입력한 값(Factor·보정 등)으로 JS가 <code>--cat-scale / --cat-font / --cat-pad / --cat-chip</code> 4개 CSS 변수를 계산</li>
        <li>메인의 글자·셀·칩 크기는 <code>calc(원래크기 × 변수)</code> 로 정해지므로, 변수만 바꾸면 즉시 비례 조정됨</li>
        <li>방문자 접속 시 JS가 <b>기기 판별</b>(User-Agent로 PC/Android/iOS) → 그 기기의 저장된 값을 적용</li>
        <li><b>Factor 0=자동</b>: 화면폭 ÷ 390 으로 계산(좁을수록 작게). <b>0보다 큰 값</b>이면 그 배율 고정</li>
      </ol>
      <p class="mb-2"><b>👀 미리보기 vs 저장 (중요):</b></p>
      <ul class="mb-2" style="padding-left:20px">
        <li><b>미리보기</b> = 오른쪽 <b>복사본(index_preview.php)</b> iframe 에만 임시 반영. <b>DB 저장 안 함, 운영/방문자 영향 0</b>.</li>
        <li><b>저장</b> = DB(gangnamunni_settings)에 기록 → <b>실제 운영 메인에 반영</b>. 방문자가 새로고침하면 적용됨.</li>
      </ul>
      <p class="mb-0"><b>🔧 값 가이드:</b> 값이 <b>작을수록</b> 더 작게(한 줄에 더 많이). 모바일 기본 <b>전체보정 0.7</b> = 서브 3개(피그마 일치). 글자/높이/칩은 요소별 미세조정용(기본 1.0).</p>
    </div>
  </details>

  <div class="ms-wrap">
    <div class="ms-left">
      <!-- 일률 적용 -->
      <div class="card mb-3" style="border:2px solid var(--bs-primary,#ae1932)">
        <div class="card-header fw-bold" style="background:rgba(174,25,50,.08)"><i class="bi bi-lightning-charge"></i> 일률 적용 — 선택 대상에 값 한 번에</div>
        <div class="card-body">
          <div class="row g-2 align-items-end">
            <div class="col-6 col-md-2">
              <label class="form-label small fw-bold">적용 대상</label>
              <select id="bulkTarget" class="form-select form-select-sm">
                <option value="all">전체 (PC+And+iOS)</option>
                <option value="mobile">모바일만 (And+iOS)</option>
                <option value="pc">💻 PC 만</option>
                <option value="android">🤖 Android 만</option>
                <option value="ios">🍎 iOS 만</option>
              </select>
            </div>
            <?php foreach (['factor','adjust','font','pad','chip'] as $fk): ?>
            <div class="col-6 col-md-2">
              <label class="form-label small"><?= htmlspecialchars($fields[$fk][0]) ?></label>
              <input type="number" step="0.1" class="form-control form-control-sm" id="bulk_<?= $fk ?>" placeholder="<?= $fk==='factor'?'0':'1.0' ?>">
            </div>
            <?php endforeach; ?>
          </div>
          <div class="mt-2"><button class="btn btn-primary btn-sm" onclick="applyBulk()"><i class="bi bi-input-cursor"></i> 입력칸에 채우기</button>
            <span class="form-text">선택 대상 입력칸에 값을 채웁니다. (저장은 각 카드 [저장] 버튼)</span></div>
        </div>
      </div>

      <!-- 기기별 -->
      <div class="row g-3">
        <?php foreach ($devices as $dk=>$dlabel): ?>
        <div class="col-12 col-xl-4">
          <div class="card h-100">
            <div class="card-header fw-bold"><?= $dlabel ?></div>
            <div class="card-body">
              <?php foreach ($fields as $fk=>$fi):
                $key="cat_scale_{$dk}_{$fk}"; $val=cs($key,$defaults[$dk][$fk]); ?>
              <div class="mb-3">
                <?php if ($fk==='enabled'): ?>
                  <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="<?= $key ?>" data-dev="<?= $dk ?>" data-f="<?= $fk ?>" <?= $val==='1'?'checked':'' ?> onchange="markDirty()">
                    <label class="form-check-label fw-bold" for="<?= $key ?>"><?= htmlspecialchars($fi[0]) ?></label>
                  </div>
                  <div class="form-text"><?= $fi[2] ?></div>
                <?php else: ?>
                  <label class="form-label small fw-bold mb-1"><?= htmlspecialchars($fi[0]) ?></label>
                  <input type="number" step="0.1" class="form-control form-control-sm" id="<?= $key ?>" data-dev="<?= $dk ?>" data-f="<?= $fk ?>" value="<?= htmlspecialchars($val) ?>" oninput="markDirty()">
                  <div class="form-text" style="font-size:11.5px"><?= $fi[2] ?></div>
                <?php endif; ?>
              </div>
              <?php endforeach; ?>
              <div class="d-flex gap-2 mt-2">
                <button class="btn btn-success btn-sm flex-fill" onclick="saveDevice('<?= $dk ?>')"><i class="bi bi-save"></i> 저장 (운영 반영)</button>
                <button class="btn btn-outline-secondary btn-sm flex-fill" onclick="resetDevice('<?= $dk ?>')"><i class="bi bi-arrow-counterclockwise"></i> 원복</button>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- 미리보기 패널 (복사본 iframe) -->
    <div class="ms-preview">
      <div class="card">
        <div class="card-header fw-bold py-2"><i class="bi bi-phone"></i> 미리보기 <span id="prevLabel" class="text-muted small">(Android)</span></div>
        <div class="card-body p-2">
          <div class="phone"><iframe id="previewFrame" src="index_preview.php"></iframe></div>
          <div class="form-text mt-1">※ 복사본(index_preview.php) — 저장 전 미리보기. 운영 영향 없음.</div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
var FIELDS=['enabled','factor','adjust','font','pad','chip'];
var DEFAULTS=<?php echo json_encode($defaults); ?>;
function showAlert(m){var a=document.getElementById('saveAlert');document.getElementById('saveMsg').textContent=m;a.classList.remove('d-none');setTimeout(function(){a.classList.add('d-none');},2200);}
function markDirty(){ document.body.classList.add('ms-has-dirty'); }
function getVal(dev,f){var el=document.getElementById('cat_scale_'+dev+'_'+f);if(!el)return null;return el.type==='checkbox'?(el.checked?'1':'0'):el.value;}
function num(v,d){var n=parseFloat(v);return (n&&n>0)?n:d;}

// 입력값으로 --cat-* 계산 (index.php JS 와 동일 로직)
function calcVars(dev){
  var en=getVal(dev,'enabled');
  if(en!=='1') return {scale:'1',font:'1',pad:'1',chip:'1'};
  var manual=parseFloat(getVal(dev,'factor'));
  // 미리보기 프레임 폭 기준 (모바일=프레임폭, pc=1280 가정)
  var fw = (dev==='pc') ? 1280 : 360;
  var base=(manual&&manual>0)?manual:Math.min(1, fw/390);
  var scale=base*num(getVal(dev,'adjust'),1);
  scale=Math.max(0.4,Math.min(1.5,scale));
  return {scale:scale.toFixed(3),font:num(getVal(dev,'font'),1).toFixed(3),pad:num(getVal(dev,'pad'),1).toFixed(3),chip:num(getVal(dev,'chip'),1).toFixed(3)};
}
// 미리보기 적용 (iframe 에 값 전달 — DB 저장 아님)
function updatePreview(){
  var dev=document.getElementById('prevDevice').value;
  var v=calcVars(dev); v.type='catscale_preview';
  var f=document.getElementById('previewFrame');
  f.contentWindow.postMessage(v,'*');
  showAlert('미리보기 적용됨 ('+dev.toUpperCase()+') — 저장 전 화면입니다');
}
function refreshPreview(){
  var dev=document.getElementById('prevDevice').value;
  document.getElementById('prevLabel').textContent='('+dev.toUpperCase()+')';
  // 프레임 새로고침 후 적용
  var f=document.getElementById('previewFrame');
  f.onload=function(){ setTimeout(updatePreview,400); f.onload=null; };
  f.src='index_preview.php';
}
// 저장 (운영 반영)
function saveOne(key,value){return fetch('api_save_setting.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'key='+encodeURIComponent(key)+'&value='+encodeURIComponent(value)}).then(function(r){return r.json();});}
function saveDevice(dev){
  var jobs=[]; FIELDS.forEach(function(f){jobs.push(saveOne('cat_scale_'+dev+'_'+f,getVal(dev,f)));});
  Promise.all(jobs).then(function(){ document.body.classList.remove('ms-has-dirty'); showAlert(dev.toUpperCase()+' 저장됨 — 운영에 반영됨 (메인 새로고침)'); });
}
function resetDevice(dev){
  if(!confirm(dev.toUpperCase()+' 를 기본값으로 되돌리고 저장할까요?'))return;
  var d=DEFAULTS[dev],jobs=[];
  FIELDS.forEach(function(f){var el=document.getElementById('cat_scale_'+dev+'_'+f);if(el){if(el.type==='checkbox')el.checked=(d[f]==='1');else el.value=d[f];}jobs.push(saveOne('cat_scale_'+dev+'_'+f,d[f]));});
  Promise.all(jobs).then(function(){ showAlert(dev.toUpperCase()+' 기본값 원복+저장됨'); });
}
// 일률 = 입력칸 채우기 (저장 아님)
function applyBulk(){
  var t=document.getElementById('bulkTarget').value;
  var devs=t==='all'?['pc','android','ios']:t==='mobile'?['android','ios']:[t];
  var filled=0;
  ['factor','adjust','font','pad','chip'].forEach(function(f){
    var v=document.getElementById('bulk_'+f).value; if(v==='')return;
    devs.forEach(function(dev){var inp=document.getElementById('cat_scale_'+dev+'_'+f);if(inp){inp.value=v;filled++;}});
  });
  if(!filled){alert('값을 입력하세요');return;}
  markDirty();
  showAlert('입력칸에 채움 — [미리보기 적용] 후 [저장] 하세요');
}
</script>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
