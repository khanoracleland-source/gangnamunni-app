<?php
require_once __DIR__ . '/includes/init.php';
$member_id = is_gangnamunni_logged_in() ? get_gangnamunni_member_id() : null;

// 테이블
mysqli_query($connect, "CREATE TABLE IF NOT EXISTS gangnamunni_membership_levels (
    id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50) NOT NULL, min_points INT DEFAULT 0,
    icon VARCHAR(50) DEFAULT '', color VARCHAR(20) DEFAULT '#888',
    benefits TEXT, discount_rate DECIMAL(4,1) DEFAULT 0, sort_order INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 샘플 등급
$cnt = mysqli_query($connect, "SELECT COUNT(*) as c FROM gangnamunni_membership_levels");
if ($cnt && mysqli_fetch_assoc($cnt)['c'] == 0) {
    $levels = [
        ['브론즈', 0, 'bi-shield', '#cd7f32', '기본 혜택, 후기 작성 포인트 적립', 0],
        ['실버', 1000, 'bi-shield-fill', '#c0c0c0', '5% 할인 쿠폰 매월 지급, 우선 예약', 5],
        ['골드', 5000, 'bi-trophy', '#ffd700', '10% 할인, 무료 상담, VIP 이벤트 초대', 10],
        ['다이아몬드', 20000, 'bi-gem', '#AE1932', '15% 할인, 전용 상담사, 무료 시술 쿠폰', 15],
    ];
    foreach ($levels as $i => $l) {
        $stmt = mysqli_prepare($connect, "INSERT INTO gangnamunni_membership_levels (name,min_points,icon,color,benefits,discount_rate,sort_order) VALUES (?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'sisssdi', $l[0], $l[1], $l[2], $l[3], $l[4], $l[5], $i);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

$levels = [];
$res = mysqli_query($connect, "SELECT * FROM gangnamunni_membership_levels ORDER BY sort_order");
if ($res) while ($r = mysqli_fetch_assoc($res)) $levels[] = $r;

// 현재 사용자 포인트
$user_points = 0;
$user_level = $levels[0] ?? null;
if ($member_id) {
    $pres = mysqli_query($connect, "SELECT COALESCE(SUM(CASE WHEN type='earn' THEN amount ELSE -amount END),0) as bal FROM gangnamunni_points WHERE member_id='".mysqli_real_escape_string($connect,$member_id)."'");
    if ($pres) $user_points = (int)mysqli_fetch_assoc($pres)['bal'];
    foreach ($levels as $l) { if ($user_points >= $l['min_points']) $user_level = $l; }
}
// mysqli_close moved to end($connect);
?>
<!DOCTYPE html><html lang="ko" data-bs-theme="light"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>회원 등급 - 서울미녀</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<script>(function(){var t=localStorage.getItem('theme');if(t==='dark')document.documentElement.setAttribute('data-bs-theme','dark');})();</script>
<style>
:root{--pri:#AE1932;}*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:640px;margin:0 auto;background:var(--bs-body-bg,#f8f9fa);color:var(--bs-body-color);}
.header{padding:14px 16px;display:flex;align-items:center;gap:12px;border-bottom:1px solid var(--bs-border-color,#eee);background:var(--bs-body-bg,#fff);}
.header .back{width:36px;height:36px;border:none;background:none;font-size:20px;cursor:pointer;color:inherit;}
.header h1{font-size:17px;font-weight:700;}
.my-level{padding:24px 16px;text-align:center;background:linear-gradient(135deg,#AE1932,#a855f7);color:#fff;margin:16px;border-radius:16px;}
.my-level .icon{font-size:40px;margin-bottom:8px;}
.my-level .name{font-size:22px;font-weight:800;}
.my-level .pts{font-size:13px;opacity:0.85;margin-top:4px;}
.level-card{display:flex;align-items:center;gap:14px;padding:16px;margin:0 16px 10px;background:var(--bs-body-bg,#fff);border-radius:12px;border:1px solid var(--bs-border-color,#eee);}
.level-card.current{border-color:var(--pri);box-shadow:0 0 0 2px rgba(124,58,237,0.2);}
.level-icon{width:48px;height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;}
.level-info{flex:1;}
.level-name{font-size:15px;font-weight:700;}
.level-req{font-size:12px;color:var(--bs-secondary-color,#888);margin-top:2px;}
.level-benefits{font-size:12px;margin-top:4px;line-height:1.5;}
.level-discount{font-size:14px;font-weight:700;color:var(--pri);}
</style></head><body>
<div class="header"><button class="back" onclick="history.back()"><i class="bi bi-chevron-left"></i></button><h1>회원 등급</h1></div>
<?php if ($member_id && $user_level): ?>
<div class="my-level">
    <div class="icon"><i class="bi <?php echo $user_level['icon']; ?>"></i></div>
    <div class="name"><?php echo htmlspecialchars($user_level['name']); ?></div>
    <div class="pts">누적 <?php echo number_format($user_points); ?>P</div>
</div>
<?php endif; ?>
<div style="padding:8px 16px;font-size:13px;font-weight:600;">등급 안내</div>
<?php foreach ($levels as $l): ?>
<div class="level-card <?php echo ($user_level && $user_level['id']==$l['id'])?'current':''; ?>">
    <div class="level-icon" style="background:<?php echo $l['color']; ?>20;color:<?php echo $l['color']; ?>;"><i class="bi <?php echo $l['icon']; ?>"></i></div>
    <div class="level-info">
        <div class="level-name" style="color:<?php echo $l['color']; ?>;"><?php echo htmlspecialchars($l['name']); ?></div>
        <div class="level-req"><?php echo number_format($l['min_points']); ?>P 이상</div>
        <div class="level-benefits"><?php echo htmlspecialchars($l['benefits'] ?? ''); ?></div>
    </div>
    <?php if ($l['discount_rate'] > 0): ?><div class="level-discount"><?php echo $l['discount_rate']; ?>%</div><?php endif; ?>
</div>
<?php endforeach; ?>
<?php include_once __DIR__ . '/includes/bottom_nav.php'; ?>
</body></html>
mysqli_close($connect);
