<?php
require_once __DIR__ . '/includes/init.php';
$member_id = is_gangnamunni_logged_in() ? get_gangnamunni_member_id() : null;

// 테이블 자동 생성
mysqli_query($connect, "CREATE TABLE IF NOT EXISTS gangnamunni_qna (
    id INT AUTO_INCREMENT PRIMARY KEY, member_id VARCHAR(100), user_name VARCHAR(100),
    hospital_id INT DEFAULT NULL, title VARCHAR(300) NOT NULL, content TEXT NOT NULL,
    answer TEXT DEFAULT NULL, answered_by VARCHAR(100) DEFAULT NULL,
    answered_at DATETIME DEFAULT NULL, is_public TINYINT(1) DEFAULT 1,
    view_count INT DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// POST: 질문 등록
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $member_id) {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if ($title && $content) {
        $stmt = mysqli_prepare($connect, "INSERT INTO gangnamunni_qna (member_id, user_name, title, content) VALUES (?,?,?,?)");
        $uname = $member_id;
        mysqli_stmt_bind_param($stmt, 'ssss', $member_id, $uname, $title, $content);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header('Location: qna.php?msg=created'); exit;
    }
}

$page = max(1, intval($_GET['page'] ?? 1));
$limit = 20; $offset = ($page-1)*$limit;
$total = 0;
$res = mysqli_query($connect, "SELECT COUNT(*) as c FROM gangnamunni_qna WHERE is_public=1");
if ($res) $total = mysqli_fetch_assoc($res)['c'];

$questions = [];
$res2 = mysqli_query($connect, "SELECT q.*, h.name as hospital_name FROM gangnamunni_qna q LEFT JOIN gangnamunni_hospitals h ON q.hospital_id=h.id WHERE q.is_public=1 ORDER BY q.created_at DESC LIMIT $limit OFFSET $offset");
if ($res2) while ($r = mysqli_fetch_assoc($res2)) $questions[] = $r;
?>
<!DOCTYPE html><html lang="ko" data-bs-theme="light"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>Q&A - 서울미녀</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<script>(function(){var t=localStorage.getItem('theme');if(t==='dark')document.documentElement.setAttribute('data-bs-theme','dark');})();</script>
<style>
:root{--pri:#AE1932;}*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:640px;margin:0 auto;background:var(--bs-body-bg,#f8f9fa);color:var(--bs-body-color);}
.header{padding:14px 16px;display:flex;align-items:center;gap:12px;border-bottom:1px solid var(--bs-border-color,#eee);background:var(--bs-body-bg,#fff);}
.header .back{width:36px;height:36px;border:none;background:none;font-size:20px;cursor:pointer;color:inherit;}
.header h1{font-size:17px;font-weight:700;flex:1;}
.write-toggle{padding:4px 12px;font-size:12px;background:var(--pri);color:#fff;border:none;border-radius:6px;cursor:pointer;}
.write-form{display:none;padding:16px;background:var(--bs-body-bg,#fff);border-bottom:1px solid var(--bs-border-color,#eee);}
.write-form.show{display:block;}
.write-form input,.write-form textarea{width:100%;padding:10px 12px;border:1px solid var(--bs-border-color,#ddd);border-radius:8px;font-size:14px;margin-bottom:8px;background:var(--bs-body-bg);color:var(--bs-body-color);}
.write-form button{padding:10px 24px;background:var(--pri);color:#fff;border:none;border-radius:8px;font-size:14px;cursor:pointer;}
.qa-item{padding:14px 16px;border-bottom:1px solid var(--bs-border-color,#eee);background:var(--bs-body-bg,#fff);}
.qa-badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:600;}
.qa-badge.answered{background:#dcfce7;color:#16a34a;}
.qa-badge.waiting{background:#fef3c7;color:#d97706;}
.qa-title{font-size:14px;font-weight:600;margin:6px 0 4px;}
.qa-meta{font-size:11px;color:var(--bs-secondary-color,#888);}
.qa-answer{margin-top:8px;padding:10px 12px;background:var(--bs-tertiary-bg,#f5f5f5);border-radius:8px;font-size:13px;line-height:1.6;}
.empty{text-align:center;padding:60px 20px;color:var(--bs-secondary-color);}
</style></head><body>
<div class="header"><button class="back" onclick="history.back()"><i class="bi bi-chevron-left"></i></button><h1>Q&A</h1>
<?php if ($member_id): ?><button class="write-toggle" onclick="document.getElementById('wf').classList.toggle('show')">질문하기</button><?php endif; ?></div>
<?php if (!empty($_GET['msg'])): ?><div style="padding:10px 16px;color:#22c55e;font-size:13px;text-align:center;">질문이 등록되었습니다</div><?php endif; ?>
<form method="post" class="write-form" id="wf">
    <input type="text" name="title" placeholder="제목" required>
    <textarea name="content" rows="3" placeholder="질문 내용을 입력하세요..." required></textarea>
    <button type="submit">등록</button>
</form>
<?php if (empty($questions)): ?>
<div class="empty"><i class="bi bi-question-circle" style="font-size:48px;display:block;margin-bottom:12px;"></i>등록된 질문이 없습니다</div>
<?php else: foreach ($questions as $q): ?>
<div class="qa-item">
    <span class="qa-badge <?php echo $q['answer'] ? 'answered' : 'waiting'; ?>"><?php echo $q['answer'] ? '답변완료' : '대기중'; ?></span>
    <div class="qa-title"><?php echo htmlspecialchars($q['title']); ?></div>
    <div class="qa-meta"><?php echo htmlspecialchars($q['user_name'] ?? '익명'); ?> · <?php echo $q['created_at']; ?> · 조회 <?php echo $q['view_count']; ?></div>
    <div style="font-size:13px;margin-top:6px;color:var(--bs-body-color);line-height:1.6;"><?php echo nl2br(htmlspecialchars(mb_substr($q['content'],0,200))); ?></div>
    <?php if ($q['answer']): ?><div class="qa-answer"><strong style="color:var(--pri);">A.</strong> <?php echo nl2br(htmlspecialchars($q['answer'])); ?></div><?php endif; ?>
</div>
<?php endforeach; endif; ?>
<?php include_once __DIR__ . '/includes/bottom_nav.php'; ?>
</body></html>
