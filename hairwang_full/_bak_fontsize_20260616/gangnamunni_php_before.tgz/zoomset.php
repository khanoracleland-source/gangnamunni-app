<?php
/**
 * [테스트 전용] 모바일 zoom 쿠키 설정기
 *   zoomset.php?z=0.85&page=hospitals.php  → sb_zoom 쿠키 굽고 실제 페이지로 이동
 *   zoomset.php?z=off                       → 쿠키 삭제(원복) 후 메인으로
 *   로그인 세션 그대로 유지된 채 실제 페이지에서 zoom 만 적용해 확인 가능.
 *   운영 무영향: 쿠키 있을 때만 init.php 의 sb_zoom_test_script() 가 동작.
 */
$z    = isset($_GET['z']) ? $_GET['z'] : '1.0';
$page = isset($_GET['page']) ? basename($_GET['page']) : 'index.php';

$allow = ['index.php','hospitals.php','reviews.php','events.php','community.php',
          'columns.php','price_compare.php','treatments.php','mypage.php',
          'detail.php','my_bookings.php','hospital_ranking.php'];
if (!in_array($page, $allow)) $page = 'index.php';

$base = '/hairwang/gangnamunni/';

if ($z === 'off') {
    setcookie('sb_zoom', '', time()-3600, '/');
    header('Location: '.$base.'index.php');
    exit;
}
$zf = floatval($z);
if ($zf <= 0 || $zf > 2) $zf = 1.0;
setcookie('sb_zoom', (string)$zf, time()+3600*6, '/');   // 6시간 유지
header('Location: '.$base.$page);
exit;
